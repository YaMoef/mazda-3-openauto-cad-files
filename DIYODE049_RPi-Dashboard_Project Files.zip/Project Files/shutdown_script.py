
import RPi.GPIO as GPIO
import time
import os
import syslog

GPIO.setmode(GPIO.BOARD)

GPIO.setup(18, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)

syslog.syslog("Starting shutdown detection script...")

if not GPIO.input(18):
	print("Failsafe activated!")
	syslog.syslog(syslog.LOG_ERR, "Failsafe activated!")
	print("Cancelling shutdown script...")
	syslog.syslog(syslog.LOG_ERR, "Cancelling shutdown script...")
	exit()


while True:
	time.sleep(0.1)
	if GPIO.input(18):
		print("HIGH")
	else:
		print("LOW")
		syslog.syslog("Detected car ignition is off, shutting down system.")
		GPIO.cleanup()
		os.system("shutdown now -h")
